﻿ClipBridge - daily use
======================

Start:   double-click ClipBridge.exe (nothing else to run or install)
Setup:   on first start ClipBridge creates its own access token and shows a
         "Connect your iPhone" window with the address + token for both Shortcuts.
         Open it again any time: tray icon -> Connection setup...
Open:    click the tray icon (Home / History / Settings)
Hide:    close the window; sync keeps running in the tray
Stop:    right-click the tray icon -> Exit ClipBridge
Logs:    %LOCALAPPDATA%\ClipBridge\logs\
Data:    %LOCALAPPDATA%\ClipBridge\clipbridge.db
Config:  %APPDATA%\ClipBridge\config.json
Doctor:  ClipBridge.exe --doctor      (paths, config state, relay, LAN URL, autostart)
LAN URL: Home -> iPhone connection -> Copy address
         Use the current PC LAN IP, e.g. http://192.168.1.14:8787
Theme:   Settings -> Appearance -> System / Light / Dark

Portable/test: set CLIPBRIDGE_HOME to a folder to keep config + data there.

iPhone: see DAILY_USE.md next to this file. Never forward port 8787 on your router.
If Windows Firewall asks about ClipBridgeRelay.exe, allow it on private networks only.
